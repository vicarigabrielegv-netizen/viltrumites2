# Viltrumites (Minecraft 1.20.1 - Forge 47.x)

Mod sui Viltrumiti della serie *Invincible*. Questa versione contiene il **Viltrumita generico**.

## Cosa fa il Viltrumita
- **Spawn**: solo con l'uovo (`Uovo generatore di Viltrumita`, tab *Spawn Eggs* del creativo). 8 varianti casuali: 4 uomini e 4 donne, con la tuta bianca della tua skin.
- **Combo leggera** di 3 colpi (diretto, gancio, calcio finale con knockback), anche in volo.
- **Parata**: copre il corpo e riduce i danni; genera onda d'urto e respinge l'attaccante. Dopo una parata contrattacca.
- **Schivata**: laterale o indietro, con finestra di invulnerabilita' e scatto; poi contrattacca. Ha un tempo di recupero, quindi si puo' colpire.
- **Volo**: si alza se il giocatore e' in aria/vola (elytra, creativo) o e' lontano, lo insegue, combatte in aria e ogni tanto porta lo scontro in alto.
- **Carica in volo** (dash) contro bersagli lontani.
- **Se pari con lo scudo**: usa il colpo **rompi-scudo** (disabilita lo scudo per 10 s) oppure lo **schianto pesante** a due mani (onda d'urto ad area).
- **Parata del giocatore**: quando il tuo scudo para un suo colpo c'e' un'onda d'urto e il Viltrumita rincula; se alzi lo scudo "al volo" (parata perfetta) o pari lo schianto, **barcolla**.
- Animazioni fluide: ogni stato ha keyframe con easing e c'e' una dissolvenza di 5 tick tra una posa e l'altra.

## Compilare
1. Carica tutto il contenuto della cartella su GitHub (il workflow `.github/workflows/build.yml` compila con Java 17 e Gradle 8.1.1).
2. Scarica il jar dall'artifact `viltrumites-mod` in *Actions*.
3. Mettilo nella cartella `mods` di Minecraft 1.20.1 con Forge 47.x.

In locale: `gradle build` (Java 17), il jar finisce in `build/libs/`.

## Modificare pose e texture
Tutto passa da `tools/generate_assets.py` (richiede Pillow e numpy):

    python3 tools/generate_assets.py            # texture + Poses.java + anteprime

- `tools/skin_base.png`: la tuta di partenza. Visi, capelli e mani vengono aggiunti dallo script (lista `VARIANTS`).
- Le pose (`STANCE`, `L0_H`, ...) e le animazioni (`ANIMS`) sono in radianti; `Poses.java` e' generato.
- Bilanciamento (vita, danno, velocita'): `ViltrumiteEntity.createAttributes()`.
- Tempi e probabilita' dell'IA: `ViltrumiteCombatGoal`.

## Anteprime
Nella cartella `preview/`: pose, varianti (fronte/retro) e volti.
