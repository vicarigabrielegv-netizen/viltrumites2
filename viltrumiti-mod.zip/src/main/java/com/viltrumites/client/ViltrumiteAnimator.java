package com.viltrumites.client;

import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.util.Mth;

/**
 * Calcola la posa di tutte le parti (22 valori, vedi tools/generate_assets.py) mescolando:
 *   camminata/idle -> posizione di guardia (in combattimento) -> volo (hover/crociera con inclinazione)
 *   -> animazione a keyframe dello stato corrente (colpi, parata, schivata...) -> rinculo / colpo subito
 * e infine una dissolvenza di 5 tick dalla posa precedente a ogni cambio di stato (niente scatti).
 */
public final class ViltrumiteAnimator {
    private ViltrumiteAnimator() {}

    // indici della posa
    public static final int PX = 0, PY = 1, PZ = 2, PDY = 3;
    public static final int TX = 4, TY = 5, TZ = 6;
    public static final int HX = 7, HY = 8, HZ = 9;
    public static final int RAX = 10, RAY = 11, RAZ = 12;
    public static final int LAX = 13, LAY = 14, LAZ = 15;
    public static final int RLX = 16, RLY = 17, RLZ = 18;
    public static final int LLX = 19, LLY = 20, LLZ = 21;

    private static final float BLEND_TICKS = 5.0F;

    public static float[] compute(ViltrumiteEntity e, float pt, float limbSwing, float limbAmount, float age,
                                  float headYaw, float headPitch) {
        final int n = Poses.N;
        float[] p = new float[n];

        float fly = Mth.lerp(pt, e.prevFlyBlend, e.flyBlend);
        float combat = Mth.lerp(pt, e.prevCombatBlend, e.combatBlend);
        float speed = Mth.lerp(pt, e.prevSpeedH, e.speedH);
        float lat = Mth.lerp(pt, e.prevLat, e.lat);
        int state = e.getCombatState();

        // ---------- 1. camminata e idle a terra
        float walk = limbAmount * (1.0F - fly);
        float swing = Mth.cos(limbSwing * 0.6662F);
        float armSwing = 1.0F - combat * 0.85F;
        p[RAX] += -swing * walk * armSwing;
        p[LAX] += swing * walk * armSwing;
        p[RLX] += swing * 1.3F * walk;
        p[LLX] += -swing * 1.3F * walk;
        p[PDY] -= Math.abs(swing) * walk * combat * 1.4F;   // saltelli da pugile quando si muove

        float sway = Mth.cos(age * 0.09F) * 0.05F + 0.05F;
        float calm = 1.0F - combat;
        p[RAZ] += sway * calm;
        p[LAZ] -= sway * calm;
        p[RAX] += Mth.sin(age * 0.067F) * 0.05F * calm;
        p[LAX] -= Mth.sin(age * 0.067F) * 0.05F * calm;

        // ---------- 2. guardia da combattimento (a terra)
        blend(p, Poses.STANCE, combat * (1.0F - fly));
        if (combat > 0.01F) {   // respiro / bilanciamento
            float br = Mth.sin(age * 0.13F) * 0.03F * combat;
            p[RAX] += br;
            p[LAX] -= br;
        }

        // ---------- 3. volo
        if (fly > 0.001F) {
            float cruise = Mth.clamp((speed - 0.22F) / 0.35F, 0.0F, 1.0F);
            float[] air = new float[n];
            System.arraycopy(Poses.HOVER, 0, air, 0, n);
            blend(air, Poses.STANCE, combat * (1.0F - cruise));
            blend(air, Poses.CRUISE, cruise);
            air[RLX] += Mth.sin(age * 0.35F) * 0.07F;
            air[LLX] -= Mth.sin(age * 0.35F) * 0.07F;
            air[PDY] = 0.0F;
            blend(p, air, fly);

            float leanMax = state == ViltrumiteEntity.ST_DASH ? 1.5F : (state == ViltrumiteEntity.ST_NEUTRAL ? 1.2F : 0.3F);
            float lean = Mth.clamp(speed * 2.2F, 0.0F, leanMax);
            p[PX] += fly * (lean + 0.05F * Mth.sin(age * 0.1F));
            p[PZ] += fly * Mth.clamp(-lat * 3.0F, -0.5F, 0.5F);   // si inclina curvando
            p[HX] -= fly * lean * 0.8F;                            // continua a guardare avanti
            p[PDY] += Mth.sin(age * 0.12F) * 0.4F * fly * (1.0F - cruise);
        }

        // ---------- 4. animazione dello stato corrente
        int anim = animId(state, e.getCombatSub());
        if (anim >= 0) {
            float[] a = new float[n];
            Poses.sample(anim, progress(e, state, pt), a);
            for (int i = 0; i < n; i++) {
                if (i == PX || i == PZ) {
                    p[i] += a[i];          // il bacino somma (si somma all'inclinazione del volo)
                } else {
                    p[i] = a[i];
                }
            }
        }

        // ---------- 5. rinculo (parata) e colpo subito
        float rc = Math.max(0.0F, e.recoil - pt) / 9.0F;
        p[TX] -= 0.25F * rc;
        p[PDY] += 0.8F * rc;
        p[RAX] += 0.35F * rc;
        p[LAX] += 0.35F * rc;
        float hurt = e.hurtTime > 0 ? Math.max(0.0F, (e.hurtTime - pt)) / Math.max(1, e.hurtDuration) : 0.0F;
        p[TX] -= 0.2F * hurt;
        p[HX] -= 0.25F * hurt;

        // ---------- 6. sguardo
        p[HY] += Mth.clamp(headYaw, -60.0F, 60.0F) * Mth.DEG_TO_RAD;
        p[HX] += headPitch * Mth.DEG_TO_RAD * (1.0F - fly * 0.8F);

        // ---------- 7. dissolvenza dalla posa precedente a ogni cambio di stato
        if (e.blendPending) {
            System.arraycopy(e.lastPose, 0, e.blendFrom, 0, n);
            e.blendTicks = (int) BLEND_TICKS;
            e.blendPending = false;
        }
        if (e.blendTicks > 0) {
            float k = Mth.clamp((e.blendTicks - pt) / BLEND_TICKS, 0.0F, 1.0F);
            k = k * k * (3.0F - 2.0F * k);
            for (int i = 0; i < n; i++) {
                p[i] = p[i] + (e.blendFrom[i] - p[i]) * k;
            }
        }
        System.arraycopy(p, 0, e.lastPose, 0, n);
        return p;
    }

    private static void blend(float[] dst, float[] src, float w) {
        if (w <= 0.0F) {
            return;
        }
        for (int i = 0; i < dst.length; i++) {
            dst[i] += (src[i] - dst[i]) * w;
        }
    }

    private static int animId(int state, int sub) {
        switch (state) {
            case ViltrumiteEntity.ST_LIGHT:
                return Poses.LIGHT0 + Mth.clamp(sub, 0, 2);
            case ViltrumiteEntity.ST_HEAVY:
                return Poses.HEAVY0 + Mth.clamp(sub, 0, 1);
            case ViltrumiteEntity.ST_GUARD:
                return Poses.GUARD;
            case ViltrumiteEntity.ST_DODGE:
                return Poses.DODGE_L + Mth.clamp(sub, 0, 2);
            case ViltrumiteEntity.ST_STAGGER:
                return Poses.STAGGER;
            case ViltrumiteEntity.ST_DASH:
                return Poses.DASH;
            default:
                return -1;
        }
    }

    private static float progress(ViltrumiteEntity e, int state, float pt) {
        float t = e.stateTick + pt;
        if (state == ViltrumiteEntity.ST_GUARD || state == ViltrumiteEntity.ST_DASH) {
            return Mth.clamp(t / 4.0F, 0.0F, 1.0F);   // entra nella posa e la mantiene
        }
        return Mth.clamp(t / ViltrumiteEntity.duration(state, e.getCombatSub()), 0.0F, 1.0F);
    }
}
