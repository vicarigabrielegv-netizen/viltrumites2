package com.viltrumites.entity;

import com.viltrumites.entity.ai.ViltrumiteCombatGoal;
import com.viltrumites.fx.CombatFx;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

/**
 * Viltrumita generico.
 *
 * Il "cervello" del combattimento sta in {@link ViltrumiteCombatGoal}; qui ci sono lo stato (sincronizzato
 * col client per le animazioni), le reazioni ai colpi (parata / schivata) e il movimento in volo.
 */
public class ViltrumiteEntity extends Monster {
    // ------------------------------------------------------------------ stati
    public static final int ST_NEUTRAL = 0;
    public static final int ST_LIGHT = 1;    // sub 0..2 = colpi della combo
    public static final int ST_HEAVY = 2;    // sub 0 = schianto a due mani, sub 1 = rompi-scudo
    public static final int ST_GUARD = 3;
    public static final int ST_DODGE = 4;    // sub 0 = sinistra, 1 = destra, 2 = indietro
    public static final int ST_STAGGER = 5;
    public static final int ST_DASH = 6;     // carica in volo

    public static final int VARIANT_COUNT = 8;
    public static final byte EVT_PARRY = 100;
    public static final byte EVT_RECOIL = 101;

    private static final EntityDataAccessor<Boolean> DATA_FLYING = SynchedEntityData.defineId(ViltrumiteEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(ViltrumiteEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SUB = SynchedEntityData.defineId(ViltrumiteEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SEQ = SynchedEntityData.defineId(ViltrumiteEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_VARIANT = SynchedEntityData.defineId(ViltrumiteEntity.class, EntityDataSerializers.INT);

    /** Durata (tick) di ogni stato/animazione. */
    public static int duration(int state, int sub) {
        switch (state) {
            case ST_LIGHT: return 12;
            case ST_HEAVY: return sub == 0 ? 28 : 22;
            case ST_DODGE: return 11;
            case ST_STAGGER: return 24;
            case ST_GUARD: return 4;
            default: return 20;
        }
    }

    /** Tick in cui il colpo va a segno. */
    public static int hitTick(int state, int sub) {
        switch (state) {
            case ST_LIGHT: return 6;
            case ST_HEAVY: return sub == 0 ? 16 : 12;
            default: return 0;
        }
    }

    // ------------------------------------------------------------------ stato server + client
    public int stateTick;
    public boolean counterReady;   // dopo una parata/schivata: contrattacco immediato
    public boolean comboBroken;    // la combo e' stata interrotta da una parata del bersaglio
    private int dodgeCooldown;
    private int guardTicks;
    private int guardHits;

    // ------------------------------------------------------------------ solo animazioni (client)
    public float prevFlyBlend, flyBlend;
    public float prevCombatBlend, combatBlend;
    public float prevSpeedH, speedH;
    public float prevLat, lat;
    public int recoil;
    public int blendTicks;
    public boolean blendPending;
    public final float[] lastPose = new float[22];
    public final float[] blendFrom = new float[22];
    private double moveX, moveZ;

    public ViltrumiteEntity(EntityType<? extends ViltrumiteEntity> type, Level level) {
        super(type, level);
        this.xpReward = 40;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 100.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.ARMOR_TOUGHNESS, 4.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.FLYING_SPEED, 0.6D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ViltrumiteCombatGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FLYING, false);
        this.entityData.define(DATA_STATE, ST_NEUTRAL);
        this.entityData.define(DATA_SUB, 0);
        this.entityData.define(DATA_SEQ, 0);
        this.entityData.define(DATA_VARIANT, 0);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Variant")) {
            setVariant(tag.getInt("Variant"));
        }
        setFlying(false);
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        setVariant(this.random.nextInt(VARIANT_COUNT));
        if (reason == MobSpawnType.SPAWN_EGG || reason == MobSpawnType.COMMAND || reason == MobSpawnType.SPAWNER) {
            setPersistenceRequired();
        }
        return result;
    }

    // ------------------------------------------------------------------ accessori
    public int getVariant() {
        return Mth.clamp(this.entityData.get(DATA_VARIANT), 0, VARIANT_COUNT - 1);
    }

    public void setVariant(int v) {
        this.entityData.set(DATA_VARIANT, Mth.clamp(v, 0, VARIANT_COUNT - 1));
    }

    public boolean hasLongHair() {
        return getVariant() >= 4;
    }

    public boolean isFlying() {
        return this.entityData.get(DATA_FLYING);
    }

    public void setFlying(boolean flying) {
        if (flying != isFlying()) {
            this.entityData.set(DATA_FLYING, flying);
        }
        this.setNoGravity(flying);
    }

    public int getCombatState() {
        return this.entityData.get(DATA_STATE);
    }

    public int getCombatSub() {
        return this.entityData.get(DATA_SUB);
    }

    public int getStateTick() {
        return stateTick;
    }

    /** Cambia stato (solo server). Il contatore SEQ fa ripartire l'animazione anche a parita' di stato. */
    public void setCombatState(int state, int sub) {
        this.entityData.set(DATA_STATE, state);
        this.entityData.set(DATA_SUB, sub);
        this.entityData.set(DATA_SEQ, this.entityData.get(DATA_SEQ) + 1);
        this.stateTick = 0;
        this.blendPending = true;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_SEQ.equals(key)) {
            this.stateTick = 0;
            this.blendPending = true;
        }
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == EVT_PARRY) {
            this.recoil = 7;
        } else if (id == EVT_RECOIL) {
            this.recoil = 9;
        } else {
            super.handleEntityEvent(id);
        }
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        this.stateTick++;
        updateAnimData();
        if (this.level().isClientSide) {
            clientEffects();
        } else {
            serverTimers();
        }
    }

    private void updateAnimData() {
        prevFlyBlend = flyBlend;
        prevCombatBlend = combatBlend;
        prevSpeedH = speedH;
        prevLat = lat;
        flyBlend += ((isFlying() ? 1.0F : 0.0F) - flyBlend) * 0.2F;
        combatBlend += ((isAggressive() ? 1.0F : 0.0F) - combatBlend) * 0.18F;

        moveX = this.getX() - this.xo;
        moveZ = this.getZ() - this.zo;
        float sp = (float) Math.sqrt(moveX * moveX + moveZ * moveZ);
        double yaw = this.yBodyRot * Mth.DEG_TO_RAD;
        float latv = (float) (moveX * -Math.cos(yaw) + moveZ * -Math.sin(yaw));
        speedH += (sp - speedH) * 0.4F;
        lat += (latv - lat) * 0.4F;

        if (recoil > 0) {
            recoil--;
        }
        if (blendTicks > 0) {
            blendTicks--;
        }
    }

    private void clientEffects() {
        int st = getCombatState();
        if (isFlying() && speedH > 0.3F && this.tickCount % 2 == 0) {
            this.level().addParticle(ParticleTypes.CLOUD, this.getX() - moveX * 2.0, this.getY(0.55), this.getZ() - moveZ * 2.0,
                    -moveX * 0.1, 0.01, -moveZ * 0.1);
        }
        if (st == ST_DASH) {
            this.level().addParticle(ParticleTypes.CLOUD, this.getX(), this.getY(0.5), this.getZ(), 0.0, 0.0, 0.0);
        }
        if (st == ST_HEAVY && stateTick < hitTick(ST_HEAVY, getCombatSub())) {
            for (int i = 0; i < 2; i++) {
                this.level().addParticle(ParticleTypes.ELECTRIC_SPARK,
                        this.getRandomX(0.9), this.getY(0.4 + this.random.nextDouble() * 0.9), this.getRandomZ(0.9), 0.0, 0.02, 0.0);
            }
        }
    }

    private void serverTimers() {
        if (dodgeCooldown > 0) {
            dodgeCooldown--;
        }
        if (guardTicks > 0) {
            guardTicks--;
        }
        int st = getCombatState();
        if (st == ST_GUARD && guardTicks <= 0) {
            guardHits = 0;
            setCombatState(ST_NEUTRAL, 0);
        } else if (st == ST_DODGE && stateTick >= duration(ST_DODGE, 0)) {
            setCombatState(ST_NEUTRAL, 0);
        } else if (st == ST_STAGGER && stateTick >= duration(ST_STAGGER, 0)) {
            setCombatState(ST_NEUTRAL, 0);
        } else if ((st == ST_LIGHT || st == ST_HEAVY || st == ST_DASH) && (getTarget() == null || stateTick > 70)) {
            setCombatState(ST_NEUTRAL, 0);
        }
        if (st != ST_GUARD && guardHits > 0) {
            guardHits = 0;
        }
        if (isFlying()) {
            this.fallDistance = 0.0F;
        }
    }

    // ------------------------------------------------------------------ volo
    @Override
    public void travel(Vec3 input) {
        if (isFlying() && !this.isInWaterOrBubble()) {
            this.move(MoverType.SELF, this.getDeltaMovement());
            this.setDeltaMovement(this.getDeltaMovement().scale(0.94D));
            this.fallDistance = 0.0F;
        } else {
            super.travel(input);
        }
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    /** Distanza dal primo blocco solido sotto l'entita' (max 12 blocchi, altrimenti 99). */
    public static double groundDistance(Entity e) {
        BlockPos pos = e.blockPosition();
        for (int i = 0; i < 12; i++) {
            BlockPos p = pos.below(i);
            if (e.level().getBlockState(p).blocksMotion()) {
                return e.getY() - (p.getY() + 1.0D);
            }
        }
        return 99.0D;
    }

    /** Spinta con velocita' sincronizzata ai client (anche ai giocatori), ridotta dalla resistenza al contraccolpo. */
    public static void push(LivingEntity e, Vec3 impulse) {
        double k = 1.0D - e.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE);
        e.setDeltaMovement(e.getDeltaMovement().add(impulse.scale(Math.max(0.0D, k))));
        e.hurtMarked = true;
    }

    // ------------------------------------------------------------------ reazioni ai colpi
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide || !this.isAlive() || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurt(source, amount);
        }
        Entity attacker = source.getEntity();
        if (attacker == null || attacker instanceof ViltrumiteEntity) {
            return super.hurt(source, amount);
        }
        int st = getCombatState();
        // finestra di invulnerabilita' durante la schivata
        if (st == ST_DODGE && stateTick < 8) {
            return false;
        }
        boolean committed = st == ST_LIGHT || st == ST_HEAVY || st == ST_DASH;
        if (!committed && st != ST_STAGGER) {
            float roll = this.random.nextFloat();
            boolean projectile = source.is(DamageTypeTags.IS_PROJECTILE);
            float dodgeChance = projectile ? 0.65F : (isFlying() ? 0.5F : 0.38F);
            if (dodgeCooldown <= 0 && roll < dodgeChance) {
                startDodge(attacker);
                return false;
            }
            if (st == ST_GUARD || roll < dodgeChance + 0.30F) {
                return guardHit(source, amount, attacker);
            }
        }
        if (st == ST_HEAVY) {
            amount *= 0.6F;  // "super armor" durante il caricamento del colpo pesante
        }
        return super.hurt(source, amount);
    }

    private boolean guardHit(DamageSource source, float amount, Entity attacker) {
        if (getCombatState() != ST_GUARD) {
            setCombatState(ST_GUARD, 0);
        }
        guardTicks = 14;
        guardHits++;
        Vec3 toAttacker = attacker.position().subtract(this.position()).multiply(1.0, 0.0, 1.0);
        Vec3 dir = toAttacker.lengthSqr() > 1.0E-4 ? toAttacker.normalize() : this.getLookAngle();
        Vec3 at = this.position().add(0.0, this.getBbHeight() * 0.65, 0.0).add(dir.scale(0.7));
        if (this.level() instanceof ServerLevel server) {
            CombatFx.parry(server, at, false);
        }
        this.level().broadcastEntityEvent(this, EVT_PARRY);
        if (attacker instanceof LivingEntity victim) {
            Vec3 away = victim.position().subtract(this.position()).multiply(1.0, 0.0, 1.0);
            if (away.lengthSqr() > 1.0E-4) {
                push(victim, away.normalize().scale(0.55).add(0.0, 0.1, 0.0));
            }
        }
        boolean broken = guardHits >= 4 || amount >= 16.0F;
        if (broken) {
            guardHits = 0;
            setCombatState(ST_STAGGER, 0);
            if (this.level() instanceof ServerLevel server) {
                CombatFx.parry(server, at, true);
            }
            return super.hurt(source, amount * 0.7F);
        }
        counterReady = this.random.nextFloat() < 0.6F;
        return super.hurt(source, amount * 0.12F);
    }

    private void startDodge(Entity attacker) {
        Vec3 away = this.position().subtract(attacker.position()).multiply(1.0, 0.0, 1.0);
        if (away.lengthSqr() < 1.0E-4) {
            away = this.getLookAngle().multiply(-1.0, 0.0, -1.0);
        }
        away = away.normalize();
        double side = this.random.nextBoolean() ? 1.0 : -1.0;
        Vec3 perp = new Vec3(-away.z, 0.0, away.x).scale(side);
        boolean back = this.random.nextFloat() < 0.3F;
        Vec3 dash = back ? away : perp.add(away.scale(0.35)).normalize();

        double yaw = this.yBodyRot * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        int sub;
        if (dash.dot(fwd) < -0.75) {
            sub = 2;
        } else {
            sub = dash.dot(right) > 0 ? 1 : 0;
        }
        setCombatState(ST_DODGE, sub);
        double speed = isFlying() ? 1.15 : 0.95;
        this.setDeltaMovement(dash.scale(speed).add(0.0, isFlying() ? 0.0 : 0.18, 0.0));
        this.hasImpulse = true;
        this.dodgeCooldown = 45;
        this.counterReady = this.random.nextFloat() < 0.55F;
        if (this.level() instanceof ServerLevel server) {
            CombatFx.dodge(server, this.position().add(0.0, this.getBbHeight() * 0.5, 0.0));
        }
    }

    /** Chiamato (solo server) quando uno scudo para un nostro attacco. */
    public void onBlockedByShield(LivingEntity blocker) {
        boolean perfect = blocker.getTicksUsingItem() <= 8;   // scudo alzato "al volo"
        boolean slam = getCombatState() == ST_HEAVY && getCombatSub() == 0;
        Vec3 flat = blocker.position().subtract(this.position()).multiply(1.0, 0.0, 1.0);
        Vec3 dir = flat.lengthSqr() > 1.0E-4 ? flat.normalize() : this.getLookAngle();
        Vec3 at = blocker.position().add(0.0, blocker.getBbHeight() * 0.6, 0.0).subtract(dir.scale(0.6));
        if (this.level() instanceof ServerLevel server) {
            CombatFx.parry(server, at, perfect || slam);
        }
        push(this, dir.scale(perfect ? -1.1 : -0.45));
        if (perfect || slam) {
            setCombatState(ST_STAGGER, 0);
        } else {
            comboBroken = true;
        }
        this.level().broadcastEntityEvent(this, EVT_RECOIL);
    }

    // ------------------------------------------------------------------ suoni
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }
}
