package com.viltrumites.fx;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Effetti di particelle e suoni (solo lato server: i pacchetti arrivano ai client vicini). */
public final class CombatFx {
    private CombatFx() {}

    private static void sound(ServerLevel level, Vec3 at, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, at.x, at.y, at.z, sound, SoundSource.HOSTILE, volume, pitch);
    }

    /** Anello di particelle che si espande in orizzontale (onda d'urto). */
    public static void ring(ServerLevel level, ParticleOptions type, Vec3 c, int points, double speed, double rise) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2.0 * i / points;
            double dx = Math.cos(a);
            double dz = Math.sin(a);
            level.sendParticles(type, c.x + dx * 0.4, c.y, c.z + dz * 0.4, 0, dx, rise, dz, speed);
        }
    }

    public static void whiff(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        sound(level, at, SoundEvents.PLAYER_ATTACK_SWEEP, 0.9F, 0.8F);
    }

    /** Colpo leggero andato a segno; il terzo colpo della combo (sub 2) e' il finale. */
    public static void hit(ServerLevel level, Vec3 at, int sub) {
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 8, 0.25, 0.25, 0.25, 0.35);
        if (sub >= 2) {
            level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
            ring(level, ParticleTypes.CLOUD, at.subtract(0, 0.6, 0), 14, 0.3, 0.02);
            sound(level, at, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 1.0F, 0.7F);
        } else {
            sound(level, at, SoundEvents.PLAYER_ATTACK_STRONG, 1.0F, 0.85F);
        }
    }

    /** Colpo pesante a terra: onda d'urto sonica e anelli di polvere. */
    public static void slam(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y + 0.9, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        level.sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 0.4, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        ring(level, ParticleTypes.CLOUD, at, 32, 0.5, 0.02);
        ring(level, ParticleTypes.POOF, at.add(0, 0.2, 0), 20, 0.3, 0.05);
        sound(level, at, SoundEvents.WARDEN_ATTACK_IMPACT, 1.3F, 0.9F);
        sound(level, at, SoundEvents.GENERIC_EXPLODE, 0.7F, 1.4F);
    }

    public static void shieldBreak(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.CRIT, at.x, at.y, at.z, 24, 0.5, 0.5, 0.5, 0.6);
        ring(level, ParticleTypes.ENCHANTED_HIT, at, 24, 0.45, 0.05);
        sound(level, at, SoundEvents.SHIELD_BREAK, 1.2F, 0.8F);
    }

    /** Parata: lampo + onda d'urto. {@code big} per parate perfette o colpi pesanti. */
    public static void parry(ServerLevel level, Vec3 at, boolean big) {
        level.sendParticles(ParticleTypes.FLASH, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        ring(level, ParticleTypes.ENCHANTED_HIT, at, big ? 28 : 18, big ? 0.55 : 0.35, 0.0);
        ring(level, ParticleTypes.CLOUD, at, big ? 20 : 12, big ? 0.35 : 0.2, 0.0);
        sound(level, at, SoundEvents.SHIELD_BLOCK, 1.0F, big ? 0.6F : 0.9F);
        if (big) {
            level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
            sound(level, at, SoundEvents.GENERIC_EXPLODE, 0.5F, 1.8F);
        }
    }

    public static void dodge(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.POOF, at.x, at.y, at.z, 10, 0.3, 0.5, 0.3, 0.05);
        ring(level, ParticleTypes.CLOUD, at.subtract(0, 0.6, 0), 10, 0.2, 0.0);
        sound(level, at, SoundEvents.ENDERMAN_TELEPORT, 0.5F, 1.7F);
    }

    public static void takeOff(ServerLevel level, Vec3 at) {
        ring(level, ParticleTypes.CLOUD, at, 16, 0.3, 0.02);
        sound(level, at, SoundEvents.PHANTOM_SWOOP, 1.0F, 0.7F);
    }

    public static void dashStart(ServerLevel level, Vec3 at) {
        ring(level, ParticleTypes.CLOUD, at, 12, 0.25, 0.0);
        sound(level, at, SoundEvents.PHANTOM_SWOOP, 1.2F, 0.5F);
    }

    public static void dashImpact(ServerLevel level, Vec3 at) {
        level.sendParticles(ParticleTypes.SONIC_BOOM, at.x, at.y, at.z, 1, 0.0, 0.0, 0.0, 0.0);
        sound(level, at, SoundEvents.WARDEN_ATTACK_IMPACT, 0.9F, 1.2F);
    }
}
