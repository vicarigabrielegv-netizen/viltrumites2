package com.viltrumites.registry;

import com.viltrumites.ViltrumitesMod;
import com.viltrumites.entity.ViltrumiteEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    private ModEntities() {}

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ViltrumitesMod.MOD_ID);

    public static final RegistryObject<EntityType<ViltrumiteEntity>> VILTRUMITE = ENTITIES.register("viltrumite",
            () -> EntityType.Builder.of(ViltrumiteEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build(new ResourceLocation(ViltrumitesMod.MOD_ID, "viltrumite").toString()));
}
