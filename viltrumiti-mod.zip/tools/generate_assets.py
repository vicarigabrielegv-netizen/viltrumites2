#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Viltrumites - generatore di asset (unica fonte per pose e texture).

  python3 tools/generate_assets.py            # fa tutto
  python3 tools/generate_assets.py textures   # solo le texture
  python3 tools/generate_assets.py poses      # solo Poses.java
  python3 tools/generate_assets.py preview    # solo le anteprime PNG

- textures: parte da tools/skin_base.png (la tuta) e aggiunge visi, capelli e mani.
- poses:    scrive client/Poses.java con le animazioni a keyframe usate in gioco.
- preview:  renderizza i modelli con le STESSE pose e le stesse texture del gioco.
Richiede: Pillow, numpy.
"""
import math
import os
import random
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RES = os.path.join(ROOT, 'src/main/resources/assets/viltrumites')
TEX_DIR = os.path.join(RES, 'textures/entity/viltrumite')
POSES_JAVA = os.path.join(ROOT, 'src/main/java/com/viltrumites/client/Poses.java')
PREVIEW_DIR = os.path.join(ROOT, 'preview')
BASE_SKIN = os.path.join(HERE, 'skin_base.png')


# =====================================================================
#  TEXTURE
# =====================================================================
def mul(c, f):
    return tuple(max(0, min(255, int(round(x * f)))) for x in c[:3])


def mix(a, b, t):
    return tuple(int(round(a[i] * (1 - t) + b[i] * t)) for i in range(3))


SKINS = {  # base, ombra, luce
    'pale':  ((248, 222, 205), (231, 196, 176), (255, 236, 224)),
    'light': ((240, 198, 166), (222, 172, 140), (250, 214, 186)),
    'tan':   ((206, 152, 110), (184, 130, 92), (222, 172, 132)),
    'brown': ((140, 95, 62), (118, 76, 48), (160, 112, 76)),
    'dark':  ((100, 66, 46), (80, 50, 34), (120, 82, 58)),
}

# 0-3 uomini, 4-7 donne (capelli lunghi). In Java: hasLongHair() = variante >= 4
VARIANTS = [
    dict(sex='m', skin='light', hair=(28, 24, 24),    eyes=(88, 58, 36),  style='short', extra='mustache', fringe=[0, 1, 2, 3, 6, 7], seed=1),
    dict(sex='m', skin='pale',  hair=(214, 176, 98),  eyes=(70, 120, 190), style='short', extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=2),
    dict(sex='m', skin='brown', hair=(20, 18, 18),    eyes=(70, 46, 30),  style='buzz',  extra='beard',    fringe=[0, 1, 6, 7],       seed=3),
    dict(sex='m', skin='tan',   hair=(172, 176, 182), eyes=(80, 140, 96), style='short', extra='lines',    fringe=[0, 1, 2, 3, 4, 7], seed=4),
    dict(sex='f', skin='light', hair=(24, 20, 22),    eyes=(84, 56, 36),  style='long',  extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=5),
    dict(sex='f', skin='tan',   hair=(150, 60, 34),   eyes=(70, 140, 100), style='long', extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=6),
    dict(sex='f', skin='dark',  hair=(18, 14, 16),    eyes=(70, 44, 30),  style='long',  extra=None,       fringe=[0, 1, 2, 5, 6, 7], seed=7),
    dict(sex='f', skin='pale',  hair=(232, 226, 206), eyes=(120, 170, 220), style='long', extra=None,      fringe=[0, 1, 2, 5, 6, 7], seed=8),
]

USED_REGIONS = [(0, 16, 16, 32), (16, 16, 40, 32), (40, 16, 56, 32),
                (16, 48, 32, 64), (32, 48, 48, 64)]


def load_base():
    im = Image.open(BASE_SKIN).convert('RGBA')
    keep = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
    for (x0, y0, x1, y1) in USED_REGIONS:  # pulisce i pixel sparsi fuori dalle aree usate
        keep.paste(im.crop((x0, y0, x1, y1)), (x0, y0))
    return keep


def paint_variant(base, v):
    img = base.copy()
    P = img.load()
    skin, shade, hi = SKINS[v['skin']]
    hair = v['hair']
    hair_d, hair_l = mul(hair, 0.72), mul(hair, 1.22)
    rng = random.Random(v['seed'] * 7919)
    female = v['sex'] == 'f'

    def hp():
        r = rng.random()
        return hair_d if r < 0.22 else hair_l if r > 0.8 else hair

    def put(x, y, c):
        P[x, y] = (c[0], c[1], c[2], 255)

    def face(ox, oy, fn):
        for y in range(8):
            for x in range(8):
                c = fn(x, y)
                if c is not None:
                    put(ox + x, oy + y, c)

    fr = set(v['fringe'])
    style = v['style']

    # ---------------- strato base della testa ----------------
    face(8, 0, lambda x, y: hp())                       # top
    face(16, 0, lambda x, y: shade)                     # bottom

    def front(x, y):
        if y == 0:
            return hp()
        if y == 1:
            if female:
                return skin if x in (3, 4) else hp()
            return hp() if x in fr else skin
        if female and x in (0, 7) and y <= 6:
            return hp()
        if style == 'buzz' and y == 1:
            return hp()
        c = skin
        if y == 7:
            c = mul(skin, 0.94)
        # sopracciglia
        if y == 2:
            if female and x in (2, 5):
                c = mul(hair, 1.1)
            elif not female and x in (1, 2, 5, 6):
                c = hair_d if v['extra'] != 'lines' else mul(hair, 0.85)
        # occhi
        if y == 3:
            if x in (1, 6):
                c = (245, 245, 250)
            elif x in (2, 5):
                c = v['eyes']
        # naso
        if y == 4 and x in (3, 4):
            c = mul(skin, 0.93)
        if y == 4 and female and x in (1, 6):
            c = mix(skin, (236, 150, 150), 0.35)
        if y == 4 and v['extra'] == 'lines' and x in (1, 6):
            c = shade
        # baffi / barba
        if v['extra'] == 'mustache' and y == 4 and x in (2, 3, 4, 5):
            c = hair_d
        if v['extra'] == 'beard':
            if y == 4 and x in (0, 7):
                c = hp()
            if y == 5 and x in (0, 1, 2, 5, 6, 7):
                c = hp()
            if y == 5 and x in (3, 4):
                c = mul(skin, 0.7)
            if y == 6 and 0 <= x <= 7:
                c = hp()
            if y == 7 and 1 <= x <= 6:
                c = hp()
            return c
        # bocca
        if y == 5 and x in (3, 4):
            c = (196, 92, 104) if female else mul(skin, 0.78)
        return c

    face(8, 8, front)

    def side(x, y):  # x=0 dietro, x=7 davanti
        if female:
            if x <= 5:
                return hp()
            return hp() if y <= 2 else skin
        if y <= 1:
            return hp()
        if style == 'buzz':
            return hp() if (y == 2 and x <= 2) else skin
        if y == 2 and x <= 3:
            return hp()
        if y == 3 and x <= 2:
            return hp()
        if x in (3, 4) and y in (3, 4):
            return shade
        if v['extra'] == 'beard' and y >= 4 and x >= 4:
            return hp()
        return skin

    face(0, 8, side)
    face(16, 8, lambda x, y: side(7 - x, y))

    def back(x, y):
        if female:
            return hp()
        lim = 3 if style == 'buzz' else 5
        return hp() if y <= lim else mul(skin, 0.96)

    face(24, 8, back)

    # ---------------- strato "hat" (capelli in rilievo) ----------------
    face(40, 0, lambda x, y: hp())
    if female:
        face(40, 8, lambda x, y: hp() if (y == 0 or (y == 1 and x not in (3, 4)) or (x in (0, 7) and y <= 6)) else None)
        face(32, 8, lambda x, y: hp() if x <= 5 else None)
        face(48, 8, lambda x, y: hp() if (7 - x) <= 5 else None)
        face(56, 8, lambda x, y: hp())
    elif style == 'buzz':
        face(40, 8, lambda x, y: hp() if y == 0 else None)
        face(32, 8, lambda x, y: hp() if y == 0 else None)
        face(48, 8, lambda x, y: hp() if y == 0 else None)
        face(56, 8, lambda x, y: hp() if y <= 1 else None)
    else:
        face(40, 8, lambda x, y: hp() if (y == 0 or (y == 1 and x in (0, 1, 6, 7))) else None)
        face(32, 8, lambda x, y: hp() if (y <= 1 or (y == 2 and x <= 1)) else None)
        face(48, 8, lambda x, y: hp() if (y <= 1 or (y == 2 and (7 - x) <= 1)) else None)
        face(56, 8, lambda x, y: hp() if y <= 4 else None)

    # ---------------- cubo dei capelli lunghi (0,32) 8x12x2 ----------------
    if female:
        for y in range(32, 46):
            for x in range(0, 20):
                if 0 <= x < 20:
                    t = (y - 34) / 12.0
                    c = hp()
                    if t > 0.7 and rng.random() < 0.35:
                        c = hair_d
                    put(x, y, c)
        for x in range(0, 20):               # taglio a punta in fondo
            if rng.random() < 0.25:
                P[x, 45] = (0, 0, 0, 0)

    # ---------------- mani (ultime 2 righe delle braccia + base) ----------------
    def fist(x0, y0, front_x):
        for y in (y0, y0 + 1):
            for x in range(x0, x0 + 16):
                grp = (x - x0) // 4
                c = skin if grp in (1, 3) else mul(skin, 0.94)
                if y == y0 + 1:
                    c = mul(c, 0.94)
                if grp == 1 and y == y0 and x in (front_x + 1, front_x + 2):
                    c = hi
                put(x, y, c)

    fist(40, 30, 44)   # braccio destro: righe 30-31
    fist(32, 62, 36)   # braccio sinistro: righe 62-63
    for yy in range(16, 20):
        for xx in range(48, 52):
            put(xx, yy, shade)
    for yy in range(48, 52):
        for xx in range(40, 44):
            put(xx, yy, shade)
    return img


def make_textures():
    os.makedirs(TEX_DIR, exist_ok=True)
    base = load_base()
    out = []
    for i, v in enumerate(VARIANTS):
        im = paint_variant(base, v)
        im.save(os.path.join(TEX_DIR, 'viltrumite_%d.png' % i))
        out.append(im)
    print('texture scritte:', len(out))
    return out


def load_textures():
    return [Image.open(os.path.join(TEX_DIR, 'viltrumite_%d.png' % i)).convert('RGBA') for i in range(len(VARIANTS))]


# =====================================================================
#  POSE (indici identici a ViltrumiteAnimator.java)
# =====================================================================
N = 22


def P(pel=(0, 0, 0), dy=0.0, tor=(0, 0, 0), head=(0, 0, 0), ra=(0, 0, 0), la=(0, 0, 0), rl=(0, 0, 0), ll=(0, 0, 0)):
    return [*pel, dy, *tor, *head, *ra, *la, *rl, *ll]


def mirror(p):
    q = [0.0] * N
    q[0], q[1], q[2], q[3] = p[0], -p[1], -p[2], p[3]
    q[4], q[5], q[6] = p[4], -p[5], -p[6]
    q[7], q[8], q[9] = p[7], -p[8], -p[9]
    q[10:13] = [p[13], -p[14], -p[15]]
    q[13:16] = [p[10], -p[11], -p[12]]
    q[16:19] = [p[19], -p[20], -p[21]]
    q[19:22] = [p[16], -p[17], -p[18]]
    return q


STANCE = P(dy=1.0, tor=(0.14, 0.35, 0), head=(0.05, -0.35, 0), ra=(-1.25, -0.55, 0.05), la=(-1.45, 0.35, 0),
           rl=(0.38, 0, 0.05), ll=(-0.30, 0, -0.05))
HOVER = P(tor=(0.05, 0, 0), head=(0.1, 0, 0), ra=(-0.2, 0, 0.42), la=(-0.2, 0, -0.42),
          rl=(0.12, 0, 0.10), ll=(0.05, 0, -0.10))
CRUISE = P(head=(-0.2, 0, 0), ra=(-3.1, -0.05, 0), la=(0.18, 0, -0.12), rl=(0.10, 0, 0.05), ll=(0.04, 0, -0.05))
GUARD_POSE = P(dy=1.6, tor=(0.25, 0.15, 0), head=(0.25, -0.15, 0), ra=(-2.0, -0.75, 0.1), la=(-2.05, 0.75, -0.1),
               rl=(0.3, 0, 0.12), ll=(-0.15, 0, -0.12))
DASH_POSE = P(head=(-0.25, 0, 0), ra=(-3.1, -0.05, 0), la=(0.35, 0, -0.15), rl=(0.12, 0, 0.06), ll=(0.05, 0, -0.06))

L0_W = P(dy=1.4, tor=(0.12, 0.62, 0), head=(0.05, -0.62, 0), ra=(-0.55, -0.25, 0.15), la=(-1.5, 0.5, 0),
         rl=(0.5, 0, 0.05), ll=(-0.4, 0, -0.05))
L0_H = P(dy=1.6, tor=(0.24, -0.5, 0), head=(0.05, 0.5, 0), ra=(-1.62, -0.12, 0), la=(-1.0, 0.95, 0.1),
         rl=(-0.5, 0, 0.04), ll=(0.4, 0, -0.05))
L0_H2 = P(dy=1.6, tor=(0.25, -0.55, 0), head=(0.05, 0.55, 0), ra=(-1.66, -0.1, 0), la=(-1.0, 0.95, 0.1),
          rl=(-0.5, 0, 0.04), ll=(0.4, 0, -0.05))
L1_W = P(dy=1.3, tor=(0.10, -0.45, 0), head=(0.05, 0.45, 0), ra=(-1.3, -0.6, 0.05), la=(-1.5, -1.25, -0.1),
         rl=(0.4, 0, 0.05), ll=(-0.3, 0, -0.05))
L1_H = P(dy=1.5, tor=(0.20, 0.8, 0), head=(0.05, -0.8, 0), ra=(-1.3, -0.6, 0.05), la=(-1.55, 1.15, 0),
         rl=(0.2, 0, 0.05), ll=(-0.5, 0, -0.05))
L2_W = P(dy=1.0, tor=(-0.12, 0.2, 0), head=(0.12, -0.2, 0), ra=(-0.9, -0.4, 0.35), la=(-0.7, 0.3, -0.35),
         rl=(0.85, 0, 0.1), ll=(-0.1, 0, -0.1))
L2_H = P(dy=0.0, tor=(-0.4, 0.1, 0), head=(0.3, -0.1, 0), ra=(-0.35, 0.2, 0.7), la=(-0.45, -0.2, -0.75),
         rl=(-1.75, 0.12, 0.2), ll=(0.05, 0, -0.05))
H0_W = P(pel=(-0.05, 0, 0), dy=2.3, tor=(-0.34, 0, 0), head=(-0.18, 0, 0), ra=(-3.05, -0.12, 0.28), la=(-3.05, 0.12, -0.28),
         rl=(0.38, 0, 0.16), ll=(-0.14, 0, -0.16))
H0_H = P(dy=0.8, tor=(0.72, 0, 0), head=(0.3, 0, 0), ra=(-0.5, -0.12, 0.05), la=(-0.5, 0.12, -0.05),
         rl=(-0.4, 0, 0.1), ll=(0.4, 0, -0.1))
H1_W = P(dy=2.0, tor=(0.1, 1.0, 0), head=(0.05, -1.0, 0), ra=(0.95, -0.35, 0.25), la=(-1.6, 0.7, 0),
         rl=(0.5, 0, 0.1), ll=(-0.3, 0, -0.1))
H1_H = P(dy=1.0, tor=(0.55, -0.7, 0), head=(0.1, 0.6, 0), ra=(-1.62, -0.05, 0), la=(-0.4, 0.9, 0.3),
         rl=(-0.65, 0, 0.05), ll=(0.85, 0, -0.05))
DL_A = P(pel=(0.12, 0, 0.5), dy=0.8, tor=(0.1, 0.1, -0.2), head=(0.05, 0, -0.3), ra=(-0.7, -0.2, 0.95), la=(-0.5, 0.3, -0.6),
         rl=(0.15, 0, 0.2), ll=(-0.2, 0, -0.8))
DL_B = P(pel=(0.08, 0, 0.3), dy=0.8, tor=(0.1, 0.1, -0.15), head=(0.05, 0, -0.2), ra=(-0.8, -0.3, 0.8), la=(-0.6, 0.3, -0.5),
         rl=(0.15, 0, 0.2), ll=(-0.2, 0, -0.6))
DB_A = P(pel=(-0.5, 0, 0), dy=0.4, tor=(-0.25, 0, 0), head=(0.1, 0, 0), ra=(-1.9, -0.6, 0.1), la=(-1.9, 0.6, -0.1),
         rl=(0.5, 0, 0.05), ll=(0.45, 0, -0.05))
DB_B = P(pel=(-0.25, 0, 0), dy=0.6, tor=(-0.15, 0, 0), head=(0.1, 0, 0), ra=(-1.7, -0.6, 0.1), la=(-1.7, 0.6, -0.1),
         rl=(0.4, 0, 0.05), ll=(0.35, 0, -0.05))
ST_A = P(dy=1.0, tor=(-0.35, -0.2, 0), head=(-0.25, 0.2, 0), ra=(0.4, -0.1, 0.9), la=(0.2, 0.1, -0.8),
         rl=(0.5, 0, 0.2), ll=(-0.4, 0, -0.2))
ST_B = P(dy=1.0, tor=(-0.25, -0.1, 0), head=(-0.15, 0.1, 0), ra=(0.25, -0.1, 0.7), la=(0.1, 0.1, -0.65),
         rl=(0.45, 0, 0.18), ll=(-0.35, 0, -0.18))

# nome: [(t, posa, easing)]   easing: lin | io | out | in   (si applica al tratto che ARRIVA al keyframe)
ANIMS = [
    ('LIGHT0', [(0, STANCE, 'lin'), (0.24, L0_W, 'io'), (0.5, L0_H, 'out'), (0.64, L0_H2, 'lin'), (1, STANCE, 'io')]),
    ('LIGHT1', [(0, STANCE, 'lin'), (0.24, L1_W, 'io'), (0.5, L1_H, 'out'), (0.64, L1_H, 'lin'), (1, STANCE, 'io')]),
    ('LIGHT2', [(0, STANCE, 'lin'), (0.26, L2_W, 'io'), (0.5, L2_H, 'out'), (0.66, L2_H, 'lin'), (1, STANCE, 'io')]),
    ('HEAVY0', [(0, STANCE, 'lin'), (0.36, H0_W, 'io'), (0.5, H0_W, 'lin'), (0.58, H0_H, 'out'), (0.76, H0_H, 'lin'), (1, STANCE, 'io')]),
    ('HEAVY1', [(0, STANCE, 'lin'), (0.34, H1_W, 'io'), (0.55, H1_H, 'out'), (0.74, H1_H, 'lin'), (1, STANCE, 'io')]),
    ('GUARD', [(0, STANCE, 'lin'), (1, GUARD_POSE, 'out')]),
    ('DODGE_L', [(0, STANCE, 'lin'), (0.3, DL_A, 'out'), (0.65, DL_B, 'lin'), (1, STANCE, 'io')]),
    ('DODGE_R', [(0, STANCE, 'lin'), (0.3, mirror(DL_A), 'out'), (0.65, mirror(DL_B), 'lin'), (1, STANCE, 'io')]),
    ('DODGE_B', [(0, STANCE, 'lin'), (0.3, DB_A, 'out'), (0.65, DB_B, 'lin'), (1, STANCE, 'io')]),
    ('STAGGER', [(0, STANCE, 'lin'), (0.25, ST_A, 'out'), (0.7, ST_B, 'lin'), (1, STANCE, 'io')]),
    ('DASH', [(0, STANCE, 'lin'), (1, DASH_POSE, 'out')]),
]
EASE_CODE = {'lin': 0, 'io': 1, 'out': 2, 'in': 3}
ANIM_ID = {name: i for i, (name, _) in enumerate(ANIMS)}


def sample(name, p):
    frames = dict(ANIMS)[name]
    p = min(max(p, 0.0), 1.0)
    i = 0
    while i < len(frames) - 2 and p > frames[i + 1][0]:
        i += 1
    t0, a, _ = frames[i]
    t1, b, e = frames[i + 1]
    span = t1 - t0
    u = 1.0 if span <= 1e-5 else min(max((p - t0) / span, 0.0), 1.0)
    if e == 'io':
        u = u * u * (3 - 2 * u)
    elif e == 'out':
        u = 1 - (1 - u) * (1 - u)
    elif e == 'in':
        u = u * u
    return [a[k] + (b[k] - a[k]) * u for k in range(N)]


def fl(arr):
    return '{' + ', '.join('%.4fF' % x for x in arr) + '}'


def write_poses_java():
    L = []
    L.append('package com.viltrumites.client;\n')
    L.append('// FILE GENERATO da tools/generate_assets.py - modifica le pose nello script Python e rigenera.')
    L.append('public final class Poses {')
    L.append('    private Poses() {}\n')
    L.append('    public static final int N = %d;' % N)
    for name, i in ANIM_ID.items():
        L.append('    public static final int %s = %d;' % (name, i))
    L.append('')
    L.append('    public static final float[] STANCE = %s;' % fl(STANCE))
    L.append('    public static final float[] HOVER = %s;' % fl(HOVER))
    L.append('    public static final float[] CRUISE = %s;\n' % fl(CRUISE))
    L.append('    private static final float[][] TIMES = {')
    for name, fr in ANIMS:
        L.append('        {' + ', '.join('%.4fF' % f[0] for f in fr) + '},  // ' + name)
    L.append('    };')
    L.append('    private static final int[][] EASE = {')
    for name, fr in ANIMS:
        L.append('        {' + ', '.join(str(EASE_CODE[f[2]]) for f in fr) + '},')
    L.append('    };')
    L.append('    private static final float[][][] FRAMES = {')
    for name, fr in ANIMS:
        L.append('        {  // ' + name)
        for f in fr:
            L.append('            ' + fl(f[1]) + ',')
        L.append('        },')
    L.append('    };\n')
    L.append('''    /** Campiona l'animazione {@code anim} al progresso {@code p} (0..1) e scrive N valori in {@code out}. */
    public static void sample(int anim, float p, float[] out) {
        float[] t = TIMES[anim];
        float[][] f = FRAMES[anim];
        int[] e = EASE[anim];
        p = Math.max(0F, Math.min(1F, p));
        int i = 0;
        while (i < t.length - 2 && p > t[i + 1]) {
            i++;
        }
        float span = t[i + 1] - t[i];
        float u = span <= 1.0E-5F ? 1F : (p - t[i]) / span;
        u = Math.max(0F, Math.min(1F, u));
        switch (e[i + 1]) {
            case 1 -> u = u * u * (3F - 2F * u);
            case 2 -> u = 1F - (1F - u) * (1F - u);
            case 3 -> u = u * u;
            default -> { }
        }
        for (int k = 0; k < N; k++) {
            out[k] = f[i][k] + (f[i + 1][k] - f[i][k]) * u;
        }
    }
}''')
    os.makedirs(os.path.dirname(POSES_JAVA), exist_ok=True)
    with open(POSES_JAVA, 'w') as fh:
        fh.write('\n'.join(L) + '\n')
    print('scritto', POSES_JAVA)


# =====================================================================
#  RENDER DI ANTEPRIMA (stessa rig del gioco)
# =====================================================================
# nome, parent, pivot, uv, box(x,y,z,w,h,d), inflate, indice posa (rotazione) | None
PARTS = [
    ('pelvis', None, (0, 12, 0), None, None, 0.0, 0),
    ('torso', 'pelvis', (0, 0, 0), (16, 16), (-4, -12, -2, 8, 12, 4), 0.0, 4),
    ('head', 'torso', (0, -12, 0), (0, 0), (-4, -8, -4, 8, 8, 8), 0.0, 7),
    ('hat', 'head', (0, 0, 0), (32, 0), (-4, -8, -4, 8, 8, 8), 0.5, None),
    ('long_hair', 'head', (0, 0, 0), (0, 32), (-4, -7, 2, 8, 12, 2), 0.25, None),
    ('right_arm', 'torso', (-5, -10, 0), (40, 16), (-3, -2, -2, 4, 12, 4), 0.0, 10),
    ('left_arm', 'torso', (5, -10, 0), (32, 48), (-1, -2, -2, 4, 12, 4), 0.0, 13),
    ('right_leg', 'pelvis', (-1.9, 0, 0), (0, 16), (-2, 0, -2, 4, 12, 4), 0.0, 16),
    ('left_leg', 'pelvis', (1.9, 0, 0), (16, 48), (-2, 0, -2, 4, 12, 4), 0.0, 19),
]


def rot_zyx(x, y, z):
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def mat4(R, t):
    M = np.eye(4)
    M[:3, :3] = R
    M[:3, 3] = t
    return M


def cube_faces(box, uv, infl):
    x, y, z, w, h, d = box
    u, v = uv
    X0, X1, Y0, Y1, Z0, Z1 = x - infl, x + w + infl, y - infl, y + h + infl, z - infl, z + d + infl
    return [
        (lambda s, t: (X0 + s * (X1 - X0), Y0 + t * (Y1 - Y0), Z0), (u + d, v + d, w, h), (0, 0, -1)),        # fronte
        (lambda s, t: (X1 - s * (X1 - X0), Y0 + t * (Y1 - Y0), Z1), (u + 2 * d + w, v + d, w, h), (0, 0, 1)),  # retro
        (lambda s, t: (X0, Y0 + t * (Y1 - Y0), Z1 - s * (Z1 - Z0)), (u, v + d, d, h), (-1, 0, 0)),             # destra
        (lambda s, t: (X1, Y0 + t * (Y1 - Y0), Z0 + s * (Z1 - Z0)), (u + d + w, v + d, d, h), (1, 0, 0)),      # sinistra
        (lambda s, t: (X0 + s * (X1 - X0), Y0, Z1 - t * (Z1 - Z0)), (u + d, v, w, d), (0, -1, 0)),             # alto
        (lambda s, t: (X0 + s * (X1 - X0), Y1, Z0 + t * (Z1 - Z0)), (u + d + w, v, w, d), (0, 1, 0)),          # basso
    ]


def draw_tri(img, zbuf, pts, uvs, tex, bright):
    H, W = zbuf.shape
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    minx, maxx = max(int(math.floor(min(xs))), 0), min(int(math.ceil(max(xs))), W - 1)
    miny, maxy = max(int(math.floor(min(ys))), 0), min(int(math.ceil(max(ys))), H - 1)
    if minx > maxx or miny > maxy:
        return
    (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = pts
    den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
    if abs(den) < 1e-9:
        return
    X, Y = np.meshgrid(np.arange(minx, maxx + 1) + 0.5, np.arange(miny, maxy + 1) + 0.5)
    l0 = ((y1 - y2) * (X - x2) + (x2 - x1) * (Y - y2)) / den
    l1 = ((y2 - y0) * (X - x2) + (x0 - x2) * (Y - y2)) / den
    l2 = 1 - l0 - l1
    inside = (l0 >= -1e-6) & (l1 >= -1e-6) & (l2 >= -1e-6)
    if not inside.any():
        return
    z = l0 * z0 + l1 * z1 + l2 * z2
    u = l0 * uvs[0][0] + l1 * uvs[1][0] + l2 * uvs[2][0]
    v = l0 * uvs[0][1] + l1 * uvs[1][1] + l2 * uvs[2][1]
    ui = np.clip(np.floor(u).astype(int), 0, 63)
    vi = np.clip(np.floor(v).astype(int), 0, 63)
    col = tex[vi, ui]
    sl = (slice(miny, maxy + 1), slice(minx, maxx + 1))
    ok = inside & (col[..., 3] >= 128) & (z < zbuf[sl])
    zbuf[sl][ok] = z[ok]
    rgb = np.clip(col[..., :3].astype(float) * bright, 0, 255).astype(np.uint8)
    region = img[sl]
    region[ok, :3] = rgb[ok]
    region[ok, 3] = 255


def view_matrix(yaw, pitch):
    return rot_zyx(pitch, yaw, 0)


def render_figure(tex, pose, yaw=0.0, pitch=0.0, scale=8, size=(400, 400), center=(0, 12, 0), long_hair=True):
    W, H = size
    img = np.zeros((H, W, 4), dtype=np.uint8)
    zbuf = np.full((H, W), 1e9)
    tex_a = np.array(tex)
    Rv = view_matrix(yaw, pitch)
    cen = Rv @ np.array(center, dtype=float)
    mats = {}
    light = np.array([-0.4, -0.7, -0.6])
    light /= np.linalg.norm(light)
    for name, parent, pivot, uv, box, infl, idx in PARTS:
        if name == 'pelvis':
            piv = (0, 12 + pose[3], 0)
            r = (pose[0], pose[1], pose[2])
        else:
            piv = pivot
            r = tuple(pose[idx:idx + 3]) if idx is not None else (0, 0, 0)
        local = mat4(rot_zyx(*r), piv)
        mats[name] = (mats[parent] if parent else np.eye(4)) @ local
        if box is None or (name == 'long_hair' and not long_hair):
            continue
        M = mats[name]
        for fn, (fu, fv, fw, fh), nrm in cube_faces(box, uv, infl):
            corners, uvq = [], []
            for (s, t) in ((0, 0), (1, 0), (1, 1), (0, 1)):
                p = np.array(fn(s, t) + (1.0,))
                wp = (M @ p)[:3]
                q = Rv @ wp - cen
                corners.append((W / 2 + q[0] * scale, H / 2 + q[1] * scale, q[2]))
                uvq.append((fu + s * fw, fv + t * fh))
            n = Rv @ (M[:3, :3] @ np.array(nrm, dtype=float))
            bright = 0.6 + 0.4 * max(0.0, float(n @ light))
            draw_tri(img, zbuf, [corners[0], corners[1], corners[2]], [uvq[0], uvq[1], uvq[2]], tex_a, bright)
            draw_tri(img, zbuf, [corners[0], corners[2], corners[3]], [uvq[0], uvq[2], uvq[3]], tex_a, bright)
    return Image.fromarray(img, 'RGBA')


def get_font(sz):
    for p in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'):
        if os.path.exists(p):
            return ImageFont.truetype(p, sz)
    return ImageFont.load_default()


def backdrop(w, h):
    top, bot = np.array([46, 54, 70]), np.array([22, 26, 36])
    g = np.linspace(0, 1, h)[:, None, None]
    arr = (top * (1 - g) + bot * g).repeat(w, axis=1).astype(np.uint8)
    return Image.fromarray(arr, 'RGB').convert('RGBA')


def shadow(canvas, cx, cy, rw, rh):
    sh = Image.new('RGBA', canvas.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse((cx - rw, cy - rh, cx + rw, cy + rh), fill=(0, 0, 0, 90))
    canvas.alpha_composite(sh)


def pose_from(name, p):
    return sample(name, p)


def make_preview():
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    texs = load_textures()
    font, small = get_font(22), get_font(16)

    # ---------- 1) pose di combattimento / volo ----------
    cruise = list(CRUISE)
    cruise[0] += 1.25
    cruise[7] -= 1.25 * 0.8
    hover = list(STANCE)
    hover[0] += 0.12
    hover[3] = 0
    poses = [
        ('Posizione di guardia', list(STANCE)),
        ('Combo 1 - diretto', pose_from('LIGHT0', 0.5)),
        ('Combo 2 - gancio', pose_from('LIGHT1', 0.5)),
        ('Combo 3 - calcio', pose_from('LIGHT2', 0.5)),
        ('Pesante - carica', pose_from('HEAVY0', 0.4)),
        ('Pesante - impatto', pose_from('HEAVY0', 0.6)),
        ('Rompi-scudo', pose_from('HEAVY1', 0.56)),
        ('Parata', pose_from('GUARD', 1.0)),
        ('Schivata laterale', pose_from('DODGE_L', 0.35)),
        ('Barcollamento', pose_from('STAGGER', 0.3)),
        ('Volo in crociera', cruise),
        ('Volo da combattimento', hover),
    ]
    cols, cw, ch = 6, 400, 440
    rows = (len(poses) + cols - 1) // cols
    sheet = backdrop(cols * cw, rows * ch)
    tex = texs[0]
    for i, (label, pose) in enumerate(poses):
        cx, cy = (i % cols) * cw, (i // cols) * ch
        flying = label.startswith('Volo')
        yaw = math.radians(-90) if label == 'Volo in crociera' else math.radians(-32)
        fig = render_figure(tex, pose, yaw=yaw, pitch=math.radians(-8), scale=8.5, size=(cw, ch - 40),
                            center=(0, 8, 0) if not flying else (0, 8, 0))
        if not flying:
            shadow(sheet, cx + cw // 2, cy + 36 + (ch - 40) // 2 + int(16 * 8.5) - 6, 70, 13)
        sheet.alpha_composite(fig, (cx, cy + 36))
        ImageDraw.Draw(sheet).text((cx + 14, cy + 8), label, font=font, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anteprima_pose.png'))

    # ---------- 2) tutte le varianti: fronte e retro ----------
    cw, ch = 300, 380
    sheet = backdrop(cw * 4, ch * 4)
    names = ['Uomo 1 (baffi)', 'Uomo 2 (biondo)', 'Uomo 3 (barba)', 'Uomo 4 (capelli grigi)',
             'Donna 1 (nero)', 'Donna 2 (rosso)', 'Donna 3 (scuri)', 'Donna 4 (platino)']
    for i, im in enumerate(texs):
        col, row = i % 4, (i // 4) * 2
        for k, yaw in enumerate((math.radians(-25), math.radians(155))):
            cx, cy = col * cw, (row + k) * ch
            shadow(sheet, cx + cw // 2, cy + 30 + int((175 + 17 * 9.5)) - 150, 55, 11)
            fig = render_figure(im, STANCE if k == 0 else list(STANCE), yaw=yaw, pitch=math.radians(-6), scale=9.5,
                                size=(cw, ch - 30), center=(0, 7, 0), long_hair=(i >= 4))
            sheet.alpha_composite(fig, (cx, cy + 30))
            ImageDraw.Draw(sheet).text((cx + 12, cy + 6), names[i] + (' - fronte' if k == 0 else ' - retro'),
                                       font=small, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anteprima_varianti.png'))

    # ---------- 3) volti e mani (ingrandimento) ----------
    cell = 8 * 14
    sheet = backdrop((cell + 70) * 4 + 30, (cell + 60) * 2 + 20)
    d = ImageDraw.Draw(sheet)
    for i, im in enumerate(texs):
        x0, y0 = 20 + (i % 4) * (cell + 70), 10 + (i // 4) * (cell + 60)
        face = im.crop((8, 8, 16, 16)).resize((cell, cell), Image.NEAREST)
        hat = im.crop((40, 8, 48, 16)).resize((cell, cell), Image.NEAREST)
        base = face.copy()
        base.alpha_composite(hat)
        sheet.alpha_composite(base, (x0, y0))
        d.text((x0, y0 + cell + 4), names[i], font=small, fill=(235, 240, 250))
    sheet.convert('RGB').save(os.path.join(PREVIEW_DIR, 'anteprima_volti.png'))
    print('anteprime scritte in', PREVIEW_DIR)


if __name__ == '__main__':
    what = set(sys.argv[1:]) or {'textures', 'poses', 'preview'}
    if 'textures' in what:
        make_textures()
    if 'poses' in what:
        write_poses_java()
    if 'preview' in what:
        make_preview()
